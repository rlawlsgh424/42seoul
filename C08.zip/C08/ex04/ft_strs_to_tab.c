/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strs_to_tab.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: chaejkim <chaejkim@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2021/10/26 18:23:41 by chaejkim          #+#    #+#             */
/*   Updated: 2021/10/26 18:23:42 by chaejkim         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include "ft_stock_str.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	while (str[i])
		i++;
	return (i);
}

char	*ft_strcpy_m(char *src)
{
	int		i;
	int		len;
	char	*dest;

	len = ft_strlen(src);
	dest = (char *)malloc(sizeof(char) * (len + 1));
	if (!dest)
		return (NULL);
	i = 0;
	while (src[i])
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = 0;
	return (dest);
}

struct s_stock_str	*ft_strs_to_tab(int ac, char **av)
{
	int			i;
	t_stock_str	*pstock;

	if (ac <= 0)
		return (NULL);
	pstock = (t_stock_str *)malloc(sizeof(t_stock_str) * (ac + 1));
	if (!pstock)
		return (NULL);
	i = 0;
	while (i < ac)
	{
		pstock[i].size = ft_strlen(av[i]);
		pstock[i].str = av[i];
		pstock[i].copy = ft_strcpy_m(av[i]);
		i++;
	}
	pstock[i] = (struct s_stock_str){0, 0, 0};
	return (pstock);
}
